print("======= Formulir =======")
## 
print(

)
#
nama = input("Nama Lengkap : ")
tempat = input("Tempat Lahir : ")
tanggall = input("Tanggal Lahir : ")
alamat = input("Alamat Sekarang : ")
nohp = int(input("Nomor Hp : "))
prodi = input("Program Studi Mu : ")
hobi = input("Hobby : ")
#
print(

)
#
print("========= Hasil ==========")
##
print("Nama Lengkap Mu : " + str(nama))
print("Tempat Lahir Mu Di : "+ str(tempat))
print("Kamu Lahir Pada Tanggal : ", tanggall)
print("Kamu Tinggal Sekarang Di : "+ str(alamat))
print("Nomor Hp Mu : ", nohp)
print("Kamu Sekarang Sedang Belajar : "+ str(prodi))
print("Kamu Senang Melakukan : "+ str(hobi))
#
print(

)
#
print("> > > Terimakasih ^_^")