nilai = int(input("Masukan Nilai : "))
pembagi = int(input("Masukan Pembagi Nya : "))

if (pembagi == 0) :
    print("Pembagi tidak boleh 0 (NOL)")
else :
    print("Hasil Nilai Bagi Nya Adalah : ", nilai / pembagi)
