def keliling_persegi(sisi):
    return 4 * sisi

def luas_persegi(sisi):
    return sisi * sisi
#di atas ini fungsi yang akan di beri sebuah argumen agar jalan
panjang = int(input("Masukan Panjang sisi = "))
#di atas ini argumen nya
print("Keliling Persegi = %d" % keliling_persegi(panjang))
print("Luas Persegi = %d" % luas_persegi(panjang))
#code di atas ini output dari variable yang akan di beri argumen yang berisi dari variable panjang