def keliling_luas_persegi(sisi):
    keliling = 4 * sisi
    luas = sisi * sisi
    print("keliling Persegi = %d" %keliling)
    print("Luas Persegi = %d" %luas)

panjang = int(input("Masukan panjang sisi : "))
keliling_luas_persegi(panjang)
