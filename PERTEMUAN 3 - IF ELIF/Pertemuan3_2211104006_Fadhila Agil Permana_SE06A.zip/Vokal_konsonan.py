print("==================================================")
#
huruf = input("Masukan Huruf : ")
vokal = ("Ini adalah jenis huruf vokal")
konsonan = ("Ini adalah jenis huruf konsonan")
#
if huruf in "aiueoAIUEO" :
    print(huruf + ", "+ vokal)
else :
    print(konsonan)
#A
print("=========================================================")