def ganjil_genap(angka):
    if (angka) %2 == 0 :
        print("Ini adalah bilangan genap")
    else :
        print("Ini bilangan Ganjil")
ganjil_genap(int(input("Masukan Bilangannya : ")))