# Buat looping namun hanya genapnya saja yang keluar
a = int(input("Masukin NO : "))

for i in range(0, a, 2):
    print(f"Ke - {i}")